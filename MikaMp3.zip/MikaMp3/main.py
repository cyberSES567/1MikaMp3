# MikaMp3.py - Versión FINAL CORREGIDA
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.slider import Slider
from kivy.uix.image import Image
from kivy.uix.textinput import TextInput
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.tabbedpanel import TabbedPanel, TabbedPanelItem
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle
from kivy.core.audio import SoundLoader
from kivy.utils import platform
from tempfile import gettempdir
import os
import threading
import json
import base64
import time
from mutagen.mp3 import MP3
from mutagen.easyid3 import EasyID3
from mutagen.id3 import ID3, APIC

# Configuración de ventana solo para Windows
if platform == "win":
    Window.size = (450, 750)
Window.clearcolor = (0.05, 0.05, 0.1, 1)

# Importar filechooser según plataforma
if platform == "android":
    from plyer import filechooser
else:
    from tkinter import filedialog, Tk

CONFIG_FILE = 'mikamp3_data.json'
PLAYLISTS_FILE = 'playlists.json'
TOPS_FILE = 'tops.json'

class Song:
    def __init__(self, path, name="", artist="", image=None):
        self.path = path
        self.name = name if name else os.path.splitext(os.path.basename(path))[0]
        self.artist = artist
        self.image = image
        self.image_loaded = False
    
    def to_dict(self):
        return {
            'path': self.path,
            'name': self.name,
            'artist': self.artist,
            'image': self.image
        }
    
    @staticmethod
    def from_dict(data):
        return Song(data['path'], data.get('name', ''), data.get('artist', ''), data.get('image'))

class MusicPlayer(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.spacing = 5
        self.padding = 10
        
        # Datos
        self.songs = []
        self.songs_dict = {}
        self.current_song_path = None
        self.sound = None
        self.current_index = 0
        self.progress_update_event = None
        self.is_playing = False
        self.current_length = 0
        self.current_pos = 0
        self.user_dragging = False
        
        # Playlists usando paths
        self.playlists = {}
        self.song_plays = {}
        
        # Modo playlist activa
        self.current_playlist = None
        self.current_playlist_paths = []
        self.current_playlist_pos = 0
        self.repeat_playlist = False
        
        # Búsqueda
        self.search_text = ""
        
        # Cargar datos
        self.load_playlists()
        self.load_tops()
        
        if "Favoritos" not in self.playlists:
            self.playlists["Favoritos"] = []
            self.save_playlists()
        
        # Configuración del ecualizador
        self.equalizer_enabled = False
        self.equalizer_bands = [0, 0, 0, 0, 0]
        
        # Fondo
        with self.canvas.before:
            Color(0.05, 0.05, 0.1, 1)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)
        
        # Reproductor superior
        player_layout = BoxLayout(orientation='vertical', size_hint=(1, 0.38), spacing=5, padding=5)
        
        # Área para imagen
        self.album_art_container = BoxLayout(size_hint=(1, 0.35))
        self.album_art = Image(source='', size_hint=(1, 1))
        self.album_art_container.add_widget(self.album_art)
        player_layout.add_widget(self.album_art_container)
        
        # Canción y artista
        self.song_label = Label(text="Sin cancion", size_hint=(1, 0.07), font_size='14sp', color=(1, 1, 1, 1))
        player_layout.add_widget(self.song_label)
        
        self.artist_label = Label(text="", size_hint=(1, 0.05), font_size='12sp', color=(0.7, 0.7, 0.7, 1))
        player_layout.add_widget(self.artist_label)
        
        # Tiempo y barra
        time_layout = BoxLayout(size_hint=(1, 0.06), spacing=5)
        self.current_time_label = Label(text="0:00", size_hint=(0.12, 1), font_size='12sp')
        self.progress_bar = Slider(min=0, max=100, value=0, size_hint=(0.76, 1))
        self.progress_bar.bind(on_touch_down=self.slider_touch_down)
        self.progress_bar.bind(on_touch_up=self.slider_touch_up)
        self.total_time_label = Label(text="0:00", size_hint=(0.12, 1), font_size='12sp')
        time_layout.add_widget(self.current_time_label)
        time_layout.add_widget(self.progress_bar)
        time_layout.add_widget(self.total_time_label)
        player_layout.add_widget(time_layout)
        
        # Botones de salto
        seek_layout = BoxLayout(size_hint=(1, 0.07), spacing=5)
        for text, sec in [("-10", -10), ("-5", -5), ("+5", 5), ("+10", 10)]:
            btn = Button(text=text, font_size='12sp', bold=True, background_color=(0.3, 0.3, 0.5, 1))
            btn.bind(on_press=lambda x, s=sec: self.seek_seconds(s))
            seek_layout.add_widget(btn)
        player_layout.add_widget(seek_layout)
        
        # Volumen y botón de repetición
        vol_repeat_layout = BoxLayout(size_hint=(1, 0.06), spacing=5)
        vol_repeat_layout.add_widget(Label(text="Vol:", size_hint=(0.1, 1), font_size='12sp'))
        self.volume_slider = Slider(min=0, max=100, value=70, size_hint=(0.6, 1))
        self.volume_slider.bind(value=self.on_volume_change)
        vol_repeat_layout.add_widget(self.volume_slider)
        self.volume_label = Label(text="70%", size_hint=(0.15, 1), font_size='12sp')
        vol_repeat_layout.add_widget(self.volume_label)
        
        # Botón de repetición de playlist
        self.repeat_btn = Button(text="⟲", font_size='16sp', size_hint=(0.15, 1), 
                                  background_color=(0.3, 0.3, 0.5, 1))
        self.repeat_btn.bind(on_press=self.toggle_repeat)
        vol_repeat_layout.add_widget(self.repeat_btn)
        player_layout.add_widget(vol_repeat_layout)
        
        # Botones principales
        main_buttons = BoxLayout(size_hint=(1, 0.09), spacing=10)
        self.prev_btn = Button(text="<<", font_size='14sp', bold=True)
        self.play_pause_btn = Button(text="Play", font_size='14sp', bold=True, background_color=(0.2, 0.7, 0.2, 1))
        self.stop_btn = Button(text="Stop", font_size='14sp', bold=True, background_color=(0.7, 0.2, 0.2, 1))
        self.next_btn = Button(text=">>", font_size='14sp', bold=True)
        self.prev_btn.bind(on_press=self.prev_song)
        self.play_pause_btn.bind(on_press=self.toggle_play_pause)
        self.stop_btn.bind(on_press=self.stop_music)
        self.next_btn.bind(on_press=self.next_song)
        main_buttons.add_widget(self.prev_btn)
        main_buttons.add_widget(self.play_pause_btn)
        main_buttons.add_widget(self.stop_btn)
        main_buttons.add_widget(self.next_btn)
        player_layout.add_widget(main_buttons)
        
        self.add_widget(player_layout)
        
        # Pestañas
        self.tabs = TabbedPanel(size_hint=(1, 0.58), do_default_tab=False)
        
        # Pestaña 1: Carpeta
        self.folder_tab = TabbedPanelItem(text="Carpeta")
        self.folder_content = BoxLayout(orientation='vertical', spacing=5, padding=5)
        
        # Barra de búsqueda
        self.search_input = TextInput(
            hint_text="🔍 Buscar canción...",
            size_hint_y=None,
            height=45,
            font_size='12sp',
            multiline=False
        )
        self.search_input.bind(text=self.filter_songs)
        self.folder_content.add_widget(self.search_input)
        
        top_buttons = BoxLayout(size_hint_y=None, height=45, spacing=5)
        load_folder_btn = Button(text="📁 Agregar Carpeta", font_size='12sp')
        load_folder_btn.bind(on_press=self.open_folder_dialog)
        load_file_btn = Button(text="🎵 Agregar Archivos", font_size='12sp')
        load_file_btn.bind(on_press=self.open_file_dialog)
        top_buttons.add_widget(load_folder_btn)
        top_buttons.add_widget(load_file_btn)
        self.folder_content.add_widget(top_buttons)
        
        self.song_scroll = ScrollView()
        self.song_list = GridLayout(cols=1, size_hint_y=None, spacing=2)
        self.song_list.bind(minimum_height=self.song_list.setter('height'))
        self.song_scroll.add_widget(self.song_list)
        self.folder_content.add_widget(self.song_scroll)
        self.folder_tab.add_widget(self.folder_content)
        self.tabs.add_widget(self.folder_tab)
        
        # Pestaña 2: Playlists
        self.playlist_tab = TabbedPanelItem(text="Playlists")
        self.playlist_content = BoxLayout(orientation='vertical', spacing=5, padding=5)
        
        # Botón crear playlist (arriba)
        create_playlist_btn = Button(text="+ Crear Playlist", size_hint_y=None, height=45, font_size='12sp')
        create_playlist_btn.bind(on_press=self.create_playlist_dialog)
        self.playlist_content.add_widget(create_playlist_btn)
        
        self.playlist_scroll = ScrollView()
        self.playlist_list = GridLayout(cols=1, size_hint_y=None, spacing=3)
        self.playlist_list.bind(minimum_height=self.playlist_list.setter('height'))
        self.playlist_scroll.add_widget(self.playlist_list)
        self.playlist_content.add_widget(self.playlist_scroll)
        
        self.playlist_tab.add_widget(self.playlist_content)
        self.tabs.add_widget(self.playlist_tab)
        
        # Pestaña 3: Ecualizador
        self.equalizer_tab = TabbedPanelItem(text="Ecualizador")
        self.equalizer_content = BoxLayout(orientation='vertical', spacing=10, padding=10)
        
        self.eq_enable_btn = Button(text="Ecualizador: OFF", size_hint_y=None, height=45, font_size='12sp', background_color=(0.5, 0.2, 0.2, 1))
        self.eq_enable_btn.bind(on_press=self.toggle_equalizer)
        self.equalizer_content.add_widget(self.eq_enable_btn)
        
        bands = [
            ("Bajos (60Hz)", 0),
            ("Medio-Bajos (250Hz)", 1),
            ("Medios (1kHz)", 2),
            ("Medio-Altos (4kHz)", 3),
            ("Agudos (16kHz)", 4)
        ]
        
        self.eq_sliders = []
        for band_name, idx in bands:
            band_layout = BoxLayout(size_hint_y=None, height=55, spacing=10)
            band_layout.add_widget(Label(text=band_name, size_hint_x=0.45, font_size='11sp'))
            slider = Slider(min=-12, max=12, value=0, size_hint_x=0.4)
            slider.bind(value=lambda instance, value, i=idx: self.update_eq_band(i, value))
            band_layout.add_widget(slider)
            value_label = Label(text="0dB", size_hint_x=0.15, font_size='10sp')
            slider.value_label = value_label
            band_layout.add_widget(value_label)
            self.equalizer_content.add_widget(band_layout)
            self.eq_sliders.append((slider, value_label))
        
        # CORREGIDO: altura automática en presets
        presets_layout = GridLayout(cols=4, size_hint_y=None, spacing=3, padding=5)
        presets_layout.add_widget(Label(text="Presets:", font_size='11sp'))
        for preset_name, values in [("Normal", [0,0,0,0,0]), ("Rock", [4,3,1,-2,-1]), ("Pop", [2,2,0,2,3]), ("Jazz", [3,2,1,2,2]), ("Rap", [5,3,0,0,-2]), ("Bajos", [8,4,0,-2,-4])]:
            btn = Button(text=preset_name, font_size='10sp')
            btn.bind(on_press=lambda x, v=values: self.apply_preset(v))
            presets_layout.add_widget(btn)
        presets_layout.bind(minimum_height=presets_layout.setter('height'))
        self.equalizer_content.add_widget(presets_layout)
        
        self.equalizer_tab.add_widget(self.equalizer_content)
        self.tabs.add_widget(self.equalizer_tab)
        
        # Pestaña 4: Top
        self.top_tab = TabbedPanelItem(text="Top")
        self.top_content = BoxLayout(orientation='vertical', spacing=5, padding=5)
        
        reset_top_btn = Button(text="Resetear Estadisticas", size_hint_y=None, height=45, font_size='12sp', background_color=(0.5, 0.2, 0.2, 1))
        reset_top_btn.bind(on_press=self.reset_top)
        self.top_content.add_widget(reset_top_btn)
        
        self.top_scroll = ScrollView()
        self.top_list = GridLayout(cols=1, size_hint_y=None, spacing=3)
        self.top_list.bind(minimum_height=self.top_list.setter('height'))
        self.top_scroll.add_widget(self.top_list)
        self.top_content.add_widget(self.top_scroll)
        
        self.top_tab.add_widget(self.top_content)
        self.tabs.add_widget(self.top_tab)
        
        self.add_widget(self.tabs)
        
        self.load_all_data()
        self.update_all_lists()
    
    # ========== MÉTODOS DE UI ==========
    def _update_rect(self, instance, value):
        self.rect.pos = instance.pos
        self.rect.size = instance.size
    
    def restore_message(self, dt):
        if self.current_song_path and self.current_song_path in self.songs_dict:
            song = self.songs_dict[self.current_song_path]
            self.song_label.text = song.name
            self.artist_label.text = song.artist if song.artist else "Sin artista"
    
    def show_temp_message(self, message):
        self.song_label.text = message
        Clock.unschedule(self.restore_message)
        Clock.schedule_once(self.restore_message, 2)
    
    # ========== BÚSQUEDA ==========
    def filter_songs(self, instance, text):
        self.search_text = text.lower().strip()
        self.update_song_list()
    
    # ========== REPETICIÓN ==========
    def toggle_repeat(self, instance):
        self.repeat_playlist = not self.repeat_playlist
        self.repeat_btn.text = "⟲" if self.repeat_playlist else "⟳"
        self.repeat_btn.background_color = (0.2, 0.7, 0.2, 1) if self.repeat_playlist else (0.3, 0.3, 0.5, 1)
        if self.repeat_playlist:
            self.show_temp_message("Repetición: ON")
        else:
            self.show_temp_message("Repetición: OFF")
    
    # ========== REPRODUCCIÓN ==========
    def slider_touch_down(self, instance, touch):
        if instance.collide_point(*touch.pos):
            self.user_dragging = True
    
    def slider_touch_up(self, instance, touch):
        if self.user_dragging:
            self.user_dragging = False
            if self.sound and self.current_length > 0:
                new_pos = (self.progress_bar.value / 100) * self.current_length
                try:
                    self.sound.seek(new_pos)
                    self.current_pos = new_pos
                except Exception as e:
                    print(f"Seek error: {e}")
    
    def seek_seconds(self, seconds):
        if self.sound and self.current_length > 0:
            new_pos = self.current_pos + seconds
            new_pos = max(0, min(new_pos, self.current_length))
            try:
                self.sound.seek(new_pos)
                self.current_pos = new_pos
                self.progress_bar.value = (new_pos / self.current_length) * 100
            except Exception as e:
                print(f"Seek error: {e}")
    
    def on_volume_change(self, instance, value):
        if self.sound:
            self.sound.volume = value / 100
        self.volume_label.text = f"{int(value)}%"
    
    def play_song_from_playlist(self, path, playlist_name):
        self.current_playlist = playlist_name
        self.current_playlist_paths = self.playlists.get(playlist_name, [])
        
        if path in self.current_playlist_paths:
            self.current_playlist_pos = self.current_playlist_paths.index(path)
        
        self.play_by_path(path)
    
    def play_by_path(self, path):
        if path in self.songs_dict:
            song = self.songs_dict[path]
            self.current_song_path = path
            self.register_play(path)
            
            try:
                audio = MP3(path)
                self.current_length = audio.info.length
            except:
                self.current_length = 180
            
            total_seconds = int(self.current_length)
            self.total_time_label.text = f"{total_seconds // 60}:{total_seconds % 60:02d}"
            
            if self.sound:
                self.sound.stop()
            
            if not song.image_loaded and song.image is None:
                self.load_album_art(path)
            
            self.sound = SoundLoader.load(path)
            
            if self.sound:
                self.sound.volume = self.volume_slider.value / 100
                self.sound.play()
                
                self.song_label.text = song.name
                self.artist_label.text = song.artist if song.artist else "Sin artista"
                
                if song.image:
                    self.update_album_art(song.image)
                else:
                    self.album_art.source = ''
                
                self.current_pos = 0
                self.is_playing = True
                self.play_pause_btn.text = "Pausa"
                self.progress_bar.value = 0
                self.current_time_label.text = "0:00"
                
                if self.progress_update_event:
                    self.progress_update_event.cancel()
                self.progress_update_event = Clock.schedule_interval(self.update_progress, 0.5)
    
    def update_progress(self, dt):
        if self.is_playing and self.sound:
            try:
                pos = self.sound.get_pos()
                if pos < 0:
                    return
                self.current_pos = pos
                
                current_seconds = int(self.current_pos)
                self.current_time_label.text = f"{current_seconds // 60}:{current_seconds % 60:02d}"
                
                if self.current_length > 0:
                    progress = (self.current_pos / self.current_length) * 100
                    if not self.user_dragging:
                        self.progress_bar.value = min(100, max(0, progress))
                
                if self.current_pos >= self.current_length - 0.5:
                    self.next_song(None)
            except Exception as e:
                print(f"Update progress error: {e}")
    
    def toggle_play_pause(self, instance):
        if self.sound:
            if self.is_playing:
                self.current_pos = self.sound.get_pos()
                if self.current_pos < 0:
                    self.current_pos = 0
                self.sound.stop()
                self.is_playing = False
                self.play_pause_btn.text = "Play"
            else:
                self.sound.play()
                try:
                    self.sound.seek(self.current_pos)
                except:
                    pass
                self.is_playing = True
                self.play_pause_btn.text = "Pausa"
    
    def stop_music(self, instance):
        if self.sound:
            self.sound.stop()
            self.is_playing = False
            self.play_pause_btn.text = "Play"
            self.current_pos = 0
            self.current_time_label.text = "0:00"
            self.progress_bar.value = 0
    
    def next_song(self, instance):
        if self.current_playlist and self.current_playlist_paths:
            if self.current_playlist_pos < len(self.current_playlist_paths) - 1:
                self.current_playlist_pos += 1
                next_path = self.current_playlist_paths[self.current_playlist_pos]
                self.play_by_path(next_path)
                return
            elif self.repeat_playlist and self.current_playlist_paths:
                self.current_playlist_pos = 0
                next_path = self.current_playlist_paths[0]
                self.play_by_path(next_path)
                return
            else:
                self.stop_music(None)
                self.show_temp_message("Playlist terminada")
                return
        
        if self.songs:
            for i, song in enumerate(self.songs):
                if song.path == self.current_song_path:
                    if i < len(self.songs) - 1:
                        self.play_by_path(self.songs[i + 1].path)
                    return
        
        self.stop_music(None)
    
    def prev_song(self, instance):
        if self.current_playlist and self.current_playlist_paths:
            if self.current_playlist_pos > 0:
                self.current_playlist_pos -= 1
                prev_path = self.current_playlist_paths[self.current_playlist_pos]
                self.play_by_path(prev_path)
                return
            elif self.repeat_playlist and self.current_playlist_paths:
                self.current_playlist_pos = len(self.current_playlist_paths) - 1
                prev_path = self.current_playlist_paths[self.current_playlist_pos]
                self.play_by_path(prev_path)
                return
        
        if self.songs:
            for i, song in enumerate(self.songs):
                if song.path == self.current_song_path:
                    if i > 0:
                        self.play_by_path(self.songs[i - 1].path)
                    return
    
    # ========== ECOUALIZADOR ==========
    def toggle_equalizer(self, instance):
        self.equalizer_enabled = not self.equalizer_enabled
        self.eq_enable_btn.text = f"Ecualizador: {'ON' if self.equalizer_enabled else 'OFF'}"
        self.eq_enable_btn.background_color = (0.2, 0.7, 0.2, 1) if self.equalizer_enabled else (0.5, 0.2, 0.2, 1)
    
    def update_eq_band(self, band_index, value):
        band_index = int(band_index)
        self.equalizer_bands[band_index] = value
        if band_index < len(self.eq_sliders):
            self.eq_sliders[band_index][1].text = f"{int(value)}dB"
    
    def apply_preset(self, values):
        for i, val in enumerate(values):
            self.equalizer_bands[i] = val
            if i < len(self.eq_sliders):
                self.eq_sliders[i][0].value = val
                self.eq_sliders[i][1].text = f"{int(val)}dB"
    
    # ========== TOP DE REPRODUCCIONES ==========
    def load_tops(self):
        try:
            if os.path.exists(TOPS_FILE):
                with open(TOPS_FILE, 'r', encoding='utf-8') as f:
                    self.song_plays = json.load(f)
            else:
                self.song_plays = {}
        except Exception as e:
            print(f"Error loading tops: {e}")
            self.song_plays = {}
    
    def save_tops(self):
        try:
            with open(TOPS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.song_plays, f, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving tops: {e}")
    
    def register_play(self, path):
        if path:
            self.song_plays[path] = self.song_plays.get(path, 0) + 1
            self.save_tops()
            self.update_top_list()
    
    def reset_top(self, instance):
        self.song_plays = {}
        self.save_tops()
        self.update_top_list()
        popup = Popup(title="Info", content=Label(text="Estadisticas reiniciadas"), size_hint=(0.6, 0.25))
        popup.open()
        Clock.schedule_once(lambda dt: popup.dismiss(), 1.5)
    
    def update_top_list(self):
        self.top_list.clear_widgets()
        sorted_songs = sorted(self.song_plays.items(), key=lambda x: x[1], reverse=True)
        
        for i, (path, plays) in enumerate(sorted_songs[:20]):
            song = self.songs_dict.get(path)
            name = song.name if song else os.path.basename(path)
            artist = song.artist if song else ""
            
            item = BoxLayout(size_hint_y=None, height=45, spacing=5)
            rank_text = f"#{i+1}. {name[:35]}"
            if artist:
                rank_text += f" - {artist[:20]}"
            info_btn = Button(text=rank_text, font_size='11sp', halign='left', size_hint_x=0.7)
            info_btn.bind(on_press=lambda x, p=path: self.play_by_path(p))
            plays_label = Label(text=f"🎧 {plays}", font_size='12sp', size_hint_x=0.3)
            item.add_widget(info_btn)
            item.add_widget(plays_label)
            self.top_list.add_widget(item)
    
    # ========== CARGAR PORTADA ==========
    def load_album_art(self, path):
        try:
            audio_id3 = ID3(path)
            for tag in audio_id3.getall('APIC'):
                img_data = base64.b64encode(tag.data).decode('utf-8')
                if path in self.songs_dict:
                    self.songs_dict[path].image = img_data
                    self.songs_dict[path].image_loaded = True
                return
        except Exception as e:
            print(f"Error loading album art: {e}")
    
    def update_album_art(self, img_data):
        try:
            temp_path = os.path.join(gettempdir(), f"mikamp3_current.jpg")
            img_bytes = base64.b64decode(img_data)
            with open(temp_path, 'wb') as f:
                f.write(img_bytes)
            self.album_art.source = temp_path
            self.album_art.reload()
        except Exception as e:
            print(f"Error updating album art: {e}")
    
    # ========== AGREGAR ARCHIVOS ==========
    def open_folder_dialog(self, instance):
        def load_in_thread(folder):
            self.load_music_from_folder(folder)
            Clock.schedule_once(lambda dt: self.update_all_lists(), 0)
        
        if platform == "android":
            from plyer import filechooser
            filechooser.choose_dir(on_selection=lambda s: load_in_thread(s[0]) if s else None)
        else:
            def select_folder_thread():
                root = Tk()
                root.withdraw()
                root.attributes('-topmost', True)
                folder = filedialog.askdirectory(title="Selecciona Carpeta")
                root.destroy()
                if folder:
                    load_in_thread(folder)
            threading.Thread(target=select_folder_thread, daemon=True).start()
    
    def open_file_dialog(self, instance):
        def load_in_thread(files):
            self.load_music_files(files)
            Clock.schedule_once(lambda dt: self.update_all_lists(), 0)
        
        if platform == "android":
            from plyer import filechooser
            filechooser.open_file(on_selection=lambda s: load_in_thread(s) if s else None, multiple=True, filters=["*.mp3", "*.ogg", "*.wav", "*.m4a", "*.flac"])
        else:
            def select_file_thread():
                root = Tk()
                root.withdraw()
                root.attributes('-topmost', True)
                files = filedialog.askopenfilenames(
                    title="Selecciona Archivos",
                    filetypes=[("Audio", "*.mp3 *.ogg *.wav *.m4a *.flac")]
                )
                root.destroy()
                if files:
                    load_in_thread(list(files))
            threading.Thread(target=select_file_thread, daemon=True).start()
    
    def load_music_files(self, file_paths):
        added = 0
        for full_path in file_paths:
            if full_path not in self.songs_dict:
                song = Song(full_path)
                
                try:
                    audio = EasyID3(full_path)
                    artist = str(audio.get('artist', [''])[0])
                    song.artist = artist
                except Exception as e:
                    print(f"Error reading metadata: {e}")
                
                self.songs.append(song)
                self.songs_dict[full_path] = song
                added += 1
        
        if added > 0:
            self.save_all_data()
            self.show_temp_message(f"Agregadas {added} canciones")
    
    def load_music_from_folder(self, folder):
        extensions = ('.mp3', '.ogg', '.wav', '.m4a', '.flac')
        added = 0
        skipped = 0
        
        try:
            for root, dirs, files in os.walk(folder):
                for file in files:
                    if file.lower().endswith(extensions):
                        full_path = os.path.join(root, file)
                        
                        if full_path in self.songs_dict:
                            skipped += 1
                            continue
                        
                        song = Song(full_path)
                        
                        try:
                            audio = EasyID3(full_path)
                            artist = str(audio.get('artist', [''])[0])
                            song.artist = artist
                        except Exception as e:
                            print(f"Error reading metadata: {e}")
                        
                        self.songs.append(song)
                        self.songs_dict[full_path] = song
                        added += 1
            
            if added > 0:
                self.save_all_data()
                self.show_temp_message(f"Agregadas {added} canciones")
                if skipped > 0:
                    self.show_temp_message(f"Agregadas {added} ({skipped} omitidas)")
            else:
                self.show_temp_message("No hay canciones nuevas")
        except Exception as e:
            print(f"Error loading folder: {e}")
            self.show_temp_message("Error al cargar")
    
    # ========== PLAYLISTS ==========
    def create_playlist_dialog(self, instance):
        content = BoxLayout(orientation='vertical', spacing=10, padding=10)
        name_input = TextInput(hint_text="Nombre", size_hint_y=None, height=45, font_size='12sp')
        
        def create(instance):
            name = name_input.text.strip()
            if name and name not in self.playlists:
                self.playlists[name] = []
                self.save_playlists()
                self.update_playlists_list()
                popup.dismiss()
        
        btn_layout = BoxLayout(size_hint_y=None, height=45, spacing=5)
        btn_layout.add_widget(Button(text="Crear", on_press=create, font_size='12sp'))
        btn_layout.add_widget(Button(text="Cancelar", on_press=lambda x: popup.dismiss(), font_size='12sp'))
        content.add_widget(Label(text="Nombre:", font_size='12sp'))
        content.add_widget(name_input)
        content.add_widget(btn_layout)
        
        popup = Popup(title="Crear Playlist", content=content, size_hint=(0.8, 0.35))
        popup.open()
    
    def add_to_playlist_dialog(self, path, song_name):
        available = [p for p in self.playlists.keys() if p != "Favoritos"]
        if not available:
            content = BoxLayout(orientation='vertical', spacing=10, padding=10)
            content.add_widget(Label(text="No hay playlists. Crea una primero.", font_size='12sp'))
            btn = Button(text="Crear Playlist", size_hint_y=None, height=45, font_size='12sp')
            btn.bind(on_press=lambda x: (popup.dismiss(), self.create_playlist_dialog(None)))
            content.add_widget(btn)
            popup = Popup(title="Info", content=content, size_hint=(0.7, 0.3))
            popup.open()
            return
        
        content = BoxLayout(orientation='vertical', spacing=5, padding=10)
        scroll = ScrollView()
        btn_layout = GridLayout(cols=1, size_hint_y=None, spacing=3)
        btn_layout.bind(minimum_height=btn_layout.setter('height'))
        
        for pl_name in available:
            btn = Button(text=pl_name, size_hint_y=None, height=50, font_size='12sp')
            btn.bind(on_press=lambda x, n=pl_name: self.add_to_playlist(path, n))
            btn_layout.add_widget(btn)
        
        scroll.add_widget(btn_layout)
        content.add_widget(scroll)
        content.add_widget(Button(text="Cerrar", size_hint_y=None, height=45, font_size='12sp', on_press=lambda x: popup.dismiss()))
        
        popup = Popup(title="Agregar a Playlist", content=content, size_hint=(0.8, 0.6))
        popup.open()
    
    def add_to_playlist(self, path, playlist_name):
        if path not in self.playlists[playlist_name]:
            self.playlists[playlist_name].append(path)
            self.save_playlists()
            self.update_playlists_list()
            self.show_temp_message(f"Agregada a {playlist_name}")
    
    def save_playlists(self):
        try:
            with open(PLAYLISTS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.playlists, f, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving playlists: {e}")
    
    def load_playlists(self):
        try:
            if os.path.exists(PLAYLISTS_FILE):
                with open(PLAYLISTS_FILE, 'r', encoding='utf-8') as f:
                    self.playlists = json.load(f)
            else:
                self.playlists = {"Favoritos": []}
        except Exception as e:
            print(f"Error loading playlists: {e}")
            self.playlists = {"Favoritos": []}
    
    def remove_from_playlist(self, playlist_name, path):
        if path in self.playlists[playlist_name]:
            self.playlists[playlist_name].remove(path)
            self.save_playlists()
            self.update_playlists_list()
    
    def delete_playlist_dialog(self, playlist_name):
        if playlist_name == "Favoritos":
            popup = Popup(title="Info", content=Label(text="No se puede eliminar Favoritos"), size_hint=(0.6, 0.25))
            popup.open()
            return
        
        content = BoxLayout(orientation='vertical', spacing=10, padding=10)
        content.add_widget(Label(text=f"¿Eliminar '{playlist_name}'?", font_size='12sp'))
        btn_layout = BoxLayout(size_hint_y=None, height=45, spacing=10)
        
        def delete(instance):
            del self.playlists[playlist_name]
            self.save_playlists()
            self.update_playlists_list()
            popup.dismiss()
        
        btn_layout.add_widget(Button(text="Eliminar", on_press=delete, background_color=(0.8, 0.2, 0.2, 1), font_size='12sp'))
        btn_layout.add_widget(Button(text="Cancelar", on_press=lambda x: popup.dismiss(), font_size='12sp'))
        content.add_widget(btn_layout)
        
        popup = Popup(title="Confirmar", content=content, size_hint=(0.7, 0.3))
        popup.open()
    
    def view_playlist_songs(self, playlist_name):
        paths = self.playlists.get(playlist_name, [])
        
        content = BoxLayout(orientation='vertical', spacing=5, padding=10)
        content.add_widget(Label(text=f"Playlist: {playlist_name}", size_hint_y=None, height=35, font_size='14sp', bold=True))
        
        scroll = ScrollView()
        songs_layout = GridLayout(cols=1, size_hint_y=None, spacing=2)
        songs_layout.bind(minimum_height=songs_layout.setter('height'))
        
        for path in paths:
            song = self.songs_dict.get(path)
            if song:
                item = BoxLayout(size_hint_y=None, height=45, spacing=5)
                btn = Button(text=song.name[:35], font_size='11sp', halign='left', size_hint_x=0.7)
                btn.bind(on_press=lambda x, p=path, pl=playlist_name: self.play_song_from_playlist(p, pl))
                
                remove_btn = Button(text="🗑️", font_size='12sp', size_hint_x=0.3, background_color=(0.7, 0.2, 0.2, 1))
                remove_btn.bind(on_press=lambda x, p=path, pl=playlist_name: self.remove_from_playlist(pl, p))
                
                item.add_widget(btn)
                item.add_widget(remove_btn)
                songs_layout.add_widget(item)
        
        scroll.add_widget(songs_layout)
        content.add_widget(scroll)
        content.add_widget(Button(text="Cerrar", size_hint_y=None, height=45, font_size='12sp', on_press=lambda x: popup.dismiss()))
        
        popup = Popup(title=f"Playlist: {playlist_name}", content=content, size_hint=(0.9, 0.7))
        popup.open()
    
    def edit_song_dialog(self, path):
        song = self.songs_dict.get(path)
        if not song:
            return
        
        content = BoxLayout(orientation='vertical', spacing=10, padding=10)
        
        content.add_widget(Label(text="Nombre:", size_hint_y=None, height=30, font_size='12sp'))
        name_input = TextInput(text=song.name, size_hint_y=None, height=45, font_size='12sp')
        content.add_widget(name_input)
        
        content.add_widget(Label(text="Artista:", size_hint_y=None, height=30, font_size='12sp'))
        artist_input = TextInput(text=song.artist, size_hint_y=None, height=45, font_size='12sp')
        content.add_widget(artist_input)
        
        temp_image = [None]
        
        def select_image():
            if platform == "android":
                from plyer import filechooser
                filechooser.open_file(on_selection=lambda s: handle_image(s) if s else None, filters=["*.png", "*.jpg", "*.jpeg"])
            else:
                def select_thread():
                    root = Tk()
                    root.withdraw()
                    root.attributes('-topmost', True)
                    file_path = filedialog.askopenfilename(title="Imagen", filetypes=[("Imagenes", "*.png *.jpg *.jpeg")])
                    root.destroy()
                    if file_path:
                        with open(file_path, 'rb') as f:
                            img_data = base64.b64encode(f.read()).decode('utf-8')
                        temp_image[0] = img_data
                        Clock.schedule_once(lambda dt: setattr(img_status, 'text', "✓ OK"), 0)
                threading.Thread(target=select_thread, daemon=True).start()
        
        def handle_image(selection):
            if selection:
                with open(selection[0], 'rb') as f:
                    img_data = base64.b64encode(f.read()).decode('utf-8')
                temp_image[0] = img_data
                Clock.schedule_once(lambda dt: setattr(img_status, 'text', "✓ OK"), 0)
        
        img_btn = Button(text="Seleccionar Imagen", size_hint_y=None, height=45, font_size='12sp')
        img_btn.bind(on_press=lambda x: select_image())
        content.add_widget(img_btn)
        
        img_status = Label(text="Sin imagen", size_hint_y=None, height=30, font_size='11sp')
        content.add_widget(img_status)
        
        btn_layout = BoxLayout(size_hint_y=None, height=45, spacing=10)
        
        def save(instance):
            song.name = name_input.text
            song.artist = artist_input.text
            if temp_image[0]:
                song.image = temp_image[0]
            self.update_all_lists()
            self.save_all_data()
            popup.dismiss()
        
        btn_layout.add_widget(Button(text="Guardar", on_press=save, font_size='12sp'))
        btn_layout.add_widget(Button(text="Cancelar", on_press=lambda x: popup.dismiss(), font_size='12sp'))
        content.add_widget(btn_layout)
        
        popup = Popup(title="Editar Cancion", content=content, size_hint=(0.85, 0.7))
        popup.open()
    
    def confirm_delete_song(self, path):
        song = self.songs_dict.get(path)
        if not song:
            return
        
        content = BoxLayout(orientation='vertical', spacing=10, padding=10)
        content.add_widget(Label(text=f"¿Eliminar '{song.name}'?", font_size='12sp'))
        btn_layout = BoxLayout(size_hint_y=None, height=45, spacing=10)
        
        def delete(instance):
            for pl_name in self.playlists:
                if path in self.playlists[pl_name]:
                    self.playlists[pl_name].remove(path)
            
            self.songs = [s for s in self.songs if s.path != path]
            del self.songs_dict[path]
            
            if path in self.song_plays:
                del self.song_plays[path]
            
            if self.current_song_path == path:
                self.next_song(None)
            
            self.save_playlists()
            self.save_tops()
            self.update_all_lists()
            self.save_all_data()
            popup.dismiss()
        
        btn_layout.add_widget(Button(text="Eliminar", on_press=delete, background_color=(0.8, 0.2, 0.2, 1), font_size='12sp'))
        btn_layout.add_widget(Button(text="Cancelar", on_press=lambda x: popup.dismiss(), font_size='12sp'))
        content.add_widget(btn_layout)
        
        popup = Popup(title="Confirmar", content=content, size_hint=(0.7, 0.3))
        popup.open()
    
    def toggle_favorite(self, path):
        if path in self.playlists["Favoritos"]:
            self.playlists["Favoritos"].remove(path)
        else:
            self.playlists["Favoritos"].append(path)
        self.save_playlists()
        self.update_song_list()
        self.update_playlists_list()
    
    def update_all_lists(self):
        self.update_song_list()
        self.update_playlists_list()
        self.update_top_list()
    
    def add_song_widget(self, song):
        item = BoxLayout(size_hint_y=None, height=50, spacing=5)
        
        name_text = song.name
        if song.artist:
            name_text += f" - {song.artist}"
        
        info_btn = Button(text=name_text[:45], font_size='11sp', halign='left', size_hint_x=0.5)
        info_btn.bind(on_press=lambda x, p=song.path: self.play_by_path(p))
        
        playlist_btn = Button(text="PL", font_size='12sp', size_hint_x=0.1)
        playlist_btn.bind(on_press=lambda x, p=song.path, n=song.name: self.add_to_playlist_dialog(p, n))
        
        is_fav = song.path in self.playlists.get("Favoritos", [])
        fav_btn = Button(text="❤️" if is_fav else "🤍", font_size='14sp', size_hint_x=0.1)
        fav_btn.bind(on_press=lambda x, p=song.path: self.toggle_favorite(p))
        
        edit_btn = Button(text="✏️", font_size='12sp', size_hint_x=0.1)
        edit_btn.bind(on_press=lambda x, p=song.path: self.edit_song_dialog(p))
        
        delete_btn = Button(text="🗑️", font_size='12sp', size_hint_x=0.1, background_color=(0.7, 0.2, 0.2, 1))
        delete_btn.bind(on_press=lambda x, p=song.path: self.confirm_delete_song(p))
        
        item.add_widget(info_btn)
        item.add_widget(playlist_btn)
        item.add_widget(fav_btn)
        item.add_widget(edit_btn)
        item.add_widget(delete_btn)
        self.song_list.add_widget(item)
    
    def update_song_list(self):
        self.song_list.clear_widgets()
        
        search = self.search_text.lower()
        for song in self.songs:
            if search:
                if search in song.name.lower() or (song.artist and search in song.artist.lower()):
                    self.add_song_widget(song)
            else:
                self.add_song_widget(song)
    
    def update_playlists_list(self):
        self.playlist_list.clear_widgets()
        
        # Ordenar: Favoritos primero, luego el resto alfabéticamente
        sorted_names = sorted(self.playlists.keys())
        if "Favoritos" in sorted_names:
            sorted_names.remove("Favoritos")
            sorted_names.insert(0, "Favoritos")
        
        for pl_name in sorted_names:
            paths = self.playlists[pl_name]
            # CORREGIDO: altura automática
            item = BoxLayout(orientation='vertical', size_hint_y=None, spacing=3, padding=5)
            item.bind(minimum_height=item.setter('height'))
            
            header = BoxLayout(size_hint_y=None, height=40, spacing=5)
            
            view_btn = Button(text=f"{pl_name} ({len(paths)} canciones)", font_size='12sp', bold=True, size_hint_x=0.6, halign='left')
            view_btn.bind(on_press=lambda x, n=pl_name: self.view_playlist_songs(n))
            header.add_widget(view_btn)
            
            if pl_name != "Favoritos":
                edit_btn = Button(text="✏️", font_size='12sp', size_hint_x=0.2)
                edit_btn.bind(on_press=lambda x, n=pl_name: self.edit_playlist_dialog(n))
                delete_btn = Button(text="🗑️", font_size='12sp', size_hint_x=0.2, background_color=(0.7, 0.2, 0.2, 1))
                delete_btn.bind(on_press=lambda x, n=pl_name: self.delete_playlist_dialog(n))
                header.add_widget(edit_btn)
                header.add_widget(delete_btn)
            
            item.add_widget(header)
            
            # Mostrar primeras canciones
            preview = ""
            for path in paths[:3]:
                song = self.songs_dict.get(path)
                if song:
                    preview += f"• {song.name}\n"
            if len(paths) > 3:
                preview += f"... {len(paths)-3} más"
            
            if preview:
                preview_label = Label(text=preview, font_size='10sp', color=(0.8, 0.8, 0.8, 1), size_hint_y=None, halign='left')
                preview_label.bind(size=preview_label.setter('text_size'))
                item.add_widget(preview_label)
            
            self.playlist_list.add_widget(item)
    
    def edit_playlist_dialog(self, playlist_name):
        paths = self.playlists.get(playlist_name, [])
        
        content = BoxLayout(orientation='vertical', spacing=10, padding=10)
        content.add_widget(Label(text=f"Playlist: {playlist_name}", size_hint_y=None, height=35, font_size='14sp', bold=True))
        
        content.add_widget(Label(text="Canciones:", size_hint_y=None, height=30, font_size='12sp'))
        
        scroll = ScrollView(size_hint=(1, 0.4))
        songs_layout = GridLayout(cols=1, size_hint_y=None, spacing=2)
        songs_layout.bind(minimum_height=songs_layout.setter('height'))
        
        for path in paths:
            song = self.songs_dict.get(path)
            if song:
                song_item = BoxLayout(size_hint_y=None, height=40, spacing=5)
                song_item.add_widget(Label(text=song.name[:30], font_size='11sp', size_hint_x=0.7))
                remove_btn = Button(text="Eliminar", font_size='11sp', size_hint_x=0.3, background_color=(0.7, 0.2, 0.2, 1))
                remove_btn.bind(on_press=lambda x, p=path, n=playlist_name: self.remove_from_playlist(n, p))
                song_item.add_widget(remove_btn)
                songs_layout.add_widget(song_item)
        
        scroll.add_widget(songs_layout)
        content.add_widget(scroll)
        
        add_btn = Button(text="+ Agregar Canciones", size_hint_y=None, height=45, font_size='12sp')
        add_btn.bind(on_press=lambda x: self.add_songs_to_playlist(playlist_name))
        content.add_widget(add_btn)
        
        content.add_widget(Button(text="Cerrar", size_hint_y=None, height=45, font_size='12sp', on_press=lambda x: popup.dismiss()))
        
        popup = Popup(title=f"Editar: {playlist_name}", content=content, size_hint=(0.9, 0.75))
        popup.open()
    
    def add_songs_to_playlist(self, playlist_name):
        content = BoxLayout(orientation='vertical', spacing=5, padding=10)
        content.add_widget(Label(text="Selecciona canciones para agregar:", size_hint_y=None, height=35, font_size='12sp'))
        
        scroll = ScrollView(size_hint=(1, 0.8))
        songs_layout = GridLayout(cols=1, size_hint_y=None, spacing=2)
        songs_layout.bind(minimum_height=songs_layout.setter('height'))
        
        existing = set(self.playlists.get(playlist_name, []))
        for song in self.songs:
            if song.path not in existing:
                btn = Button(text=f"{song.name[:40]}", size_hint_y=None, height=45, font_size='11sp', halign='left')
                btn.bind(on_press=lambda x, p=song.path: self.add_to_playlist(p, playlist_name))
                songs_layout.add_widget(btn)
        
        scroll.add_widget(songs_layout)
        content.add_widget(scroll)
        content.add_widget(Button(text="Cerrar", size_hint_y=None, height=45, font_size='12sp', on_press=lambda x: popup.dismiss()))
        
        popup = Popup(title=f"Agregar a {playlist_name}", content=content, size_hint=(0.9, 0.7))
        popup.open()
    
    def save_all_data(self):
        try:
            data = {
                'songs': [s.to_dict() for s in self.songs],
                'current_song_path': self.current_song_path,
                'volume': self.volume_slider.value
            }
            with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False)
            self.save_playlists()
            self.save_tops()
        except Exception as e:
            print(f"Error saving data: {e}")
    
    def load_all_data(self):
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                songs_data = data.get('songs', [])
                self.songs = []
                self.songs_dict = {}
                for s_data in songs_data:
                    song = Song.from_dict(s_data)
                    self.songs.append(song)
                    self.songs_dict[song.path] = song
                
                self.current_song_path = data.get('current_song_path')
                self.volume_slider.value = data.get('volume', 70)
                
                if self.current_song_path and self.current_song_path in self.songs_dict:
                    song = self.songs_dict[self.current_song_path]
                    self.song_label.text = song.name
                    self.artist_label.text = song.artist if song.artist else "Sin artista"
                    
                    try:
                        audio = MP3(self.current_song_path)
                        self.current_length = audio.info.length
                        total_seconds = int(self.current_length)
                        self.total_time_label.text = f"{total_seconds // 60}:{total_seconds % 60:02d}"
                    except:
                        pass
                    
                    self.update_all_lists()
        except Exception as e:
            print(f"Error loading data: {e}")

class ReproductorApp(App):
    def build(self):
        return MusicPlayer()
    
    def on_stop(self):
        if hasattr(self, 'root'):
            if self.root.sound:
                self.root.sound.stop()
            self.root.save_all_data()

if __name__ == '__main__':
    ReproductorApp().run()